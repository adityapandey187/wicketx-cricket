import React,{useState} from 'react';
import {BACKEND_ON,signIn,signUp,signOut,sendRecovery,resetPassword,sendVerification} from './appwrite';

type Mode='login'|'signup'|'recovery'|'reset';

export function AccountPanel({user,onChange}:{user:any;onChange:()=>Promise<void>}){
  const params=new URLSearchParams(location.search);
  const [mode,setMode]=useState<Mode>(params.get('auth')==='recovery'?'reset':'login');
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[note,setNote]=useState('');
  async function submit(e:React.FormEvent<HTMLFormElement>){
    e.preventDefault();setBusy(true);setError('');setNote('');
    const form=e.currentTarget,data=new FormData(form);
    const email=String(data.get('email')||''),password=String(data.get('password')||'');
    try{
      if(mode==='signup'){await signUp(String(data.get('name')),email,password);await onChange();setNote('Account created. You can verify your email below.')}
      else if(mode==='login'){await signIn(email,password);await onChange()}
      else if(mode==='recovery'){await sendRecovery(email);setNote('If an account exists for this email, recovery instructions are on their way.')}
      else{const userId=params.get('userId'),secret=params.get('secret');if(!userId||!secret)throw new Error('Recovery link is missing or invalid. Request a new link.');await resetPassword(userId,secret,password);history.replaceState(null,'',location.pathname+'#Account');setMode('login');setNote('Password changed. Sign in with your new password.')}
      form.reset();
    }catch(err:any){setError(err?.code===401?'Sign-in failed. Check your details and try again.':err?.message||'Request failed. Try again.')}
    finally{setBusy(false)}
  }
  async function run(action:()=>Promise<unknown>,message:string){setBusy(true);setError('');try{await action();setNote(message);await onChange()}catch(err:any){setError(err?.message||'Request failed.')}finally{setBusy(false)}}
  if(!BACKEND_ON)return <section className="account-panel panel"><h1>Account setup pending</h1><p>Cloud login and saved matches are not connected yet. You can browse the demo and save matches on this device.</p></section>;
  return <section className="account-panel panel">
    <p className="eyebrow">YOUR WICKETX ACCOUNT</p>
    <h1>{user?'Your profile':mode==='signup'?'Create an account':mode==='recovery'?'Recover your password':mode==='reset'?'Choose a new password':'Welcome back'}</h1>
    {error&&<p role="alert" className="form-error">{error}</p>}
    {note&&<p role="status" className="form-notice">{note}</p>}
    {user?<><p>{user.name}</p><p>{user.email}</p><p>Email {user.emailVerification?'verified':'not yet verified'}</p>
      {!user.emailVerification&&<button className="outline" disabled={busy} onClick={()=>run(sendVerification,'Verification email sent.')}>Send verification email</button>}
      <button className="primary" disabled={busy} onClick={()=>run(signOut,'Signed out.')}>Sign out</button></>:
    <><form onSubmit={submit}>
      {mode==='signup'&&<label>Name<input name="name" autoComplete="name" maxLength={128} required/></label>}
      {mode!=='reset'&&<label>Email<input name="email" type="email" autoComplete="email" required/></label>}
      {mode!=='recovery'&&<label>Password<input name="password" type="password" autoComplete={mode==='login'?'current-password':'new-password'} minLength={8} maxLength={256} required/></label>}
      <button className="primary" disabled={busy}>{busy?'Please wait':mode==='signup'?'Create account':mode==='recovery'?'Send recovery email':mode==='reset'?'Save password':'Sign in'}</button>
    </form>
    <div className="auth-links">{(['login','signup','recovery'] as const).map(m=><button key={m} disabled={busy} onClick={()=>{setMode(m);setError('');setNote('')}}>{m==='login'?'Sign in':m==='signup'?'Create account':'Forgot password?'}</button>)}</div></>}
    <p className="tiny-note">WicketX uses Appwrite for account details and private saved matches. Scores marked LIVE are near-live from CricketData; everything else is illustrative demo data. No uploads, analytics or real-time subscriptions.</p>
  </section>;
}
