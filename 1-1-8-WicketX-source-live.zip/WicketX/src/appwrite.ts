import {Client,Account,TablesDB,ID,Permission,Role,Query} from 'appwrite';
import type {Match} from './data';

const env=(import.meta as any).env as Record<string,string|undefined>;
export const BACKEND_ON=!!(env.VITE_APPWRITE_ENDPOINT&&env.VITE_APPWRITE_PROJECT_ID&&env.VITE_APPWRITE_DATABASE_ID);
const client=new Client();
if(BACKEND_ON)client.setEndpoint(env.VITE_APPWRITE_ENDPOINT!).setProject(env.VITE_APPWRITE_PROJECT_ID!);
const account=new Account(client);
const tables=new TablesDB(client);
const DB_ID=env.VITE_APPWRITE_DATABASE_ID||'';
const MATCHES_TABLE=env.VITE_APPWRITE_MATCHES_TABLE||'matches';
const SAVES_TABLE=env.VITE_APPWRITE_SAVES_TABLE||'saved_matches';

export type SaveRow={id:string;matchId:string};

export async function loadMatches():Promise<Match[]>{
  const res=await tables.listRows({databaseId:DB_ID,tableId:MATCHES_TABLE,queries:[Query.limit(100)]});
  const parsed=res.rows.map((row:any)=>{
    if(row.dataMode!=='demo'&&row.dataMode!=='live')throw new Error('Unsupported match data mode');
    const m=JSON.parse(row.payload);
    if(!m.id||!Array.isArray(m.teams)||m.teams.length!==2)throw new Error('Invalid match record');
    return {...m,live:row.dataMode==='live'} as Match;
  });
  return parsed.sort((a,b)=>Number(b.live?1:0)-Number(a.live?1:0));
}

export async function listSaves():Promise<SaveRow[]>{
  const out:SaveRow[]=[];let cursor='';
  for(;;){
    const res=await tables.listRows({databaseId:DB_ID,tableId:SAVES_TABLE,queries:[Query.limit(100),...(cursor?[Query.cursorAfter(cursor)]:[])]});
    out.push(...res.rows.map((r:any)=>({id:r.$id,matchId:String(r.matchId)})));
    if(res.rows.length<100)break;
    cursor=res.rows[res.rows.length-1].$id;
  }
  return out;
}

export async function createSave(matchId:string,userId:string){
  return tables.createRow({databaseId:DB_ID,tableId:SAVES_TABLE,rowId:ID.unique(),data:{matchId},permissions:[Permission.read(Role.user(userId)),Permission.delete(Role.user(userId))]});
}
export async function deleteSave(rowId:string){
  return tables.deleteRow({databaseId:DB_ID,tableId:SAVES_TABLE,rowId});
}

export async function refreshSession(){return account.get();}
export async function signIn(email:string,password:string){await account.createEmailPasswordSession({email,password});return account.get();}
export async function signUp(name:string,email:string,password:string){await account.create({userId:ID.unique(),email,password,name});return signIn(email,password);}
export async function signOut(){return account.deleteSession({sessionId:'current'});}
export async function sendRecovery(email:string){return account.createRecovery({email,url:authUrl('recovery')});}
export async function resetPassword(userId:string,secret:string,password:string){return account.updateRecovery({userId,secret,password});}
export async function sendVerification(){return account.createVerification({url:authUrl('verify')});}
export async function confirmVerify(userId:string,secret:string){return account.updateVerification({userId,secret});}
export const authUrl=(mode:string)=>location.origin+location.pathname+'?auth='+mode+'#Account';
