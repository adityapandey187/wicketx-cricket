export type Match = {id:string;format:'T20'|'ODI'|'Test';status:'In play'|'Upcoming'|'Result';series:string;teams:[string,string];codes:[string,string];scores:[string,string];overs:[string,string];note:string;venue:string;time:string;day:string;women?:boolean;live?:boolean};
export const matches:Match[] = [
{id:'m1',format:'T20',status:'In play',series:'International • Sample match',teams:['India','Australia'],codes:['IND','AUS'],scores:['186/4','142/5'],overs:['20.0','16.2'],note:'Australia need 45 runs in 22 balls',venue:'Sample stadium, Mumbai',time:'7:00 PM IST',day:'Sample day 1'},
{id:'m2',format:'ODI',status:'In play',series:'International • Sample match',teams:['England','South Africa'],codes:['ENG','SA'],scores:['278/8','156/3'],overs:['50.0','28.0'],note:'South Africa need 123 runs in 132 balls',venue:'Sample ground, London',time:'3:30 PM IST',day:'Sample day 1'},
{id:'m3',format:'T20',status:'Upcoming',series:'Women’s international • Sample match',teams:['India Women','New Zealand Women'],codes:['IND-W','NZ-W'],scores:['Yet to bat','Yet to bat'],overs:['',''],note:'Match has not started',venue:'Sample oval, Bengaluru',time:'7:00 PM IST',day:'Sample day 2',women:true},
{id:'m4',format:'Test',status:'Result',series:'International • Sample match',teams:['New Zealand','Pakistan'],codes:['NZ','PAK'],scores:['326 & 241/6d','218 & 192'],overs:['',''],note:'New Zealand won by 157 runs',venue:'Sample park, Wellington',time:'4:00 AM IST',day:'Sample day 1'},
{id:'m5',format:'ODI',status:'Upcoming',series:'International • Sample match',teams:['Sri Lanka','West Indies'],codes:['SL','WI'],scores:['Yet to bat','Yet to bat'],overs:['',''],note:'Match has not started',venue:'Sample stadium, Colombo',time:'2:00 PM IST',day:'Sample day 3'},
{id:'m6',format:'T20',status:'Result',series:'Women’s international • Sample match',teams:['Australia Women','England Women'],codes:['AUS-W','ENG-W'],scores:['168/6','161/8'],overs:['20.0','20.0'],note:'Australia Women won by 7 runs',venue:'Sample ground, Sydney',time:'1:30 PM IST',day:'Sample day 1',women:true}
];
export const batting = [
['A. Sharma','c Taylor b Starc',48,31,5,2],['R. Mehta','b Ellis',32,25,3,1],['V. Rao','c Carey b Zampa',56,37,4,3],['S. Iyer','run out (Smith)',21,14,2,1],['H. Shah','not out',18,9,1,1],['R. Pant','not out',6,4,1,0]
] as const;
export const bowling = [['M. Starc','4','0','38','1'],['N. Ellis','4','0','34','1'],['J. Hazlewood','4','0','31','0'],['A. Zampa','4','0','42','1'],['G. Maxwell','4','0','36','0']];
export const balls = [
{over:'16.2',runs:'4',text:'Short of a length, pulled through the gap at midwicket. Four runs.'},
{over:'16.1',runs:'1',text:'Worked into the leg side. The batters take a single.'},
{over:'15.6',runs:'W',text:'A slower ball finds the edge. The keeper takes a clean catch.'},
{over:'15.5',runs:'0',text:'A full delivery outside off. No run.'},
{over:'15.4',runs:'6',text:'Clears the front leg and sends it over long-on for six.'},
{over:'15.3',runs:'2',text:'Driven wide of cover. Two runs added.'}
];
export const articles = [
{id:'powerplay',tag:'THE EXPLAINER',title:'Six overs. A very different game.',intro:'Why the powerplay shapes a T20 innings, and what to watch beyond the boundaries.',minutes:3,color:'purple',body:['In a standard T20 innings, the first six overs are the powerplay. Only two fielders may be outside the fielding circle. Shortened matches can have adjusted powerplay lengths.','That gives batters a chance to find gaps, but the new ball can also swing or seam. An early wicket changes how much risk a team can afford.','Watch the balance of boundaries and dot balls. A fast start is useful, but wickets in hand can matter just as much when a team accelerates later.']},
{id:'net-run-rate',tag:'CRICKET BASICS',title:'Net run rate, without the headache',intro:'It is more than the margin of a win. Here is the idea in plain words.',minutes:4,color:'green',body:['Net run rate compares a team’s scoring rate with the scoring rate it concedes across eligible matches. It is not the average of each match’s run-rate difference.','For a simple example with full 20-over innings: scoring 180 and conceding 160 gives rates of 9.00 and 8.00 runs per over. The difference is +1.00.','All-out innings and interrupted matches have special rules. Always check the tournament playing conditions before calculating a standings tiebreak.']},
{id:'death-overs',tag:'TACTICS',title:'The art of the final four overs',intro:'Yorkers, slower balls and field placement in the closing stretch.',minutes:3,color:'orange',body:['Late in a T20 innings, batters often take more risks. Bowlers respond by changing pace, length and angle to make clean hitting harder.','A yorker aims near the batter’s feet. It can be hard to get under, but a small error can turn it into a hittable full toss.','Watch the field before the delivery. A deep square leg or a wide third can hint at a plan, although good bowlers also use those clues to surprise the batter.']}
];
export const rankingSamples = {T20:[['India',271],['Australia',259],['England',253],['New Zealand',249],['South Africa',246],['West Indies',241]],ODI:[['Australia',122],['India',119],['South Africa',112],['New Zealand',108],['England',104],['Sri Lanka',99]],Test:[['Australia',124],['India',119],['England',110],['South Africa',105],['New Zealand',100],['Pakistan',93]]};
