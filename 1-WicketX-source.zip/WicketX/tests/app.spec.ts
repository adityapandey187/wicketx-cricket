import {test,expect} from '@playwright/test';
test('navigation, filters, search, details and persistence',async({page})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('/'); await expect(page.getByText('Prototype mode.')).toBeVisible();
 await page.getByRole('button',{name:'All matches',exact:true}).click();
 await expect(page.locator('.match-card')).toHaveCount(6);
 await page.getByRole('button',{name:'Upcoming',exact:true}).click(); await expect(page.locator('.match-card')).toHaveCount(2);
 await page.getByRole('combobox',{name:'Match format'}).selectOption('ODI'); await expect(page.locator('.match-card')).toHaveCount(1);
 await page.getByRole('button',{name:'All matches',exact:true}).click();await page.getByRole('combobox').selectOption('All formats');
 await page.getByRole('textbox',{name:'Search matches'}).fill('India');await expect(page.locator('.match-card')).toHaveCount(2);
 await page.getByRole('button',{name:'Save India vs Australia',exact:true}).click();
 await page.getByRole('button',{name:'Saved matches',exact:true}).click();await expect(page.locator('.match-card')).toHaveCount(1);
 await page.reload();await expect(page.locator('.match-card')).toHaveCount(1);
 await page.locator('.match-open').click();await expect(page.getByRole('heading',{name:'India vs Australia'})).toBeVisible();
 for(const tab of ['Scorecard','Commentary','Squads','Overview']){await page.getByRole('tab',{name:tab,exact:true}).click();await expect(page.locator('.detail-panel')).toBeVisible();}
 await page.getByRole('tab',{name:'Scorecard',exact:true}).click();await expect(page.locator('tbody tr')).toHaveCount(11);
 await page.getByRole('button',{name:'Use dark theme'}).click();await page.reload();await expect(page.locator('html')).toHaveAttribute('data-theme','dark');
 await page.goto('/#Stories');await page.locator('.story-card').first().click();await expect(page.locator('.reader')).toBeVisible();
 await page.goto('/#Rankings');await page.getByRole('tab',{name:'Test',exact:true}).click();await expect(page.locator('.ranking-row')).toHaveCount(7);
 await page.goto('/#Schedule');await expect(page.locator('.schedule-row')).toHaveCount(2);
 expect(errors).toEqual([]);
});
for(const width of [320,390,768,1440])test(`layout and screenshots ${width}`,async({page})=>{
 await page.setViewportSize({width,height:900});
 for(const path of ['Home','Matches','match/m1','Schedule','Stories','story/powerplay','Rankings','Saved']){
 await page.goto('/#'+path);await page.evaluate(()=>document.fonts.ready);await expect(page.locator('main')).toBeVisible();
 expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),path+' page overflows').toBeTruthy();
 if(['Home','match/m1'].includes(path)){await page.screenshot({path:`/downloads/wicketx-${width}-${path.replace('/','-')}.png`,fullPage:true});}
 }
});
