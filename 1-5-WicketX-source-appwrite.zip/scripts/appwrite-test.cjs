const {Client,Account,TablesDB,ID,Permission,Role,Query}=require('appwrite');
// minimal cookie jar so Node behaves like a browser for Appwrite cookie sessions
const jars={anon:new Map(),a:new Map(),b:new Map()};
let activeJar=jars.anon;
const useJar=n=>{activeJar=jars[n]};
const realFetch=globalThis.fetch;
globalThis.fetch=async(url,opts={})=>{
 opts.headers=Object.assign({},opts.headers);
 if(activeJar.size)opts.headers['Cookie']=[...activeJar.entries()].map(([k,v])=>k+'='+v).join('; ');
 const res=await realFetch(url,opts);
 const sc=res.headers.getSetCookie?res.headers.getSetCookie():[];
 for(const c of sc){const [kv]=c.split(';');const i=kv.indexOf('=');const k=kv.slice(0,i).trim(),v=kv.slice(i+1).trim();if(k.startsWith('a_session'))activeJar.set(k,v);}
 return res;
};
const EP='https://fra.cloud.appwrite.io/v1',P='6ada539900103d47b12c',DB='wicketx';
const pw='WxTest!'+Math.random().toString(36).slice(2,10);
const mk=()=>{const c=new Client().setEndpoint(EP).setProject(P);return c};
const fail=[];const ok=m=>console.log('PASS:',m);const bad=m=>{console.log('FAIL:',m);fail.push(m)};
(async()=>{
 // --- anonymous ---
 const anon=mk();const at=new TablesDB(anon);
 try{const r=await at.listRows({databaseId:DB,tableId:'matches'});r.total===6?ok('anon lists 6 demo matches'):bad('anon matches total='+r.total)}catch(e){bad('anon list matches: '+e.code+' '+e.message)}
 try{await at.createRow({databaseId:DB,tableId:'matches',rowId:ID.unique(),data:{payload:'{}',dataMode:'demo'}});bad('anon could WRITE matches')}catch(e){e.code===401?ok('anon write to matches denied (401)'):bad('anon write matches: '+e.code)}
 try{await at.createRow({databaseId:DB,tableId:'saved_matches',rowId:ID.unique(),data:{matchId:'m1'}});bad('anon could create saved row')}catch(e){e.code===401?ok('anon saved_matches create denied (401)'):bad('anon saved create: '+e.code)}
 // --- two users (pre-created to dodge signup rate limits) ---
 const creds={a:['wx.probe.1792693390121@outlook.com','WxProbe!1234'],b:['wx.probe.1792693464697@outlook.com','WxProbe!1234']};
 const users={};
 for(const n of ['a','b']){
  useJar(n);
  const c=mk();const acc=new Account(c);
  try{
   await acc.createEmailPasswordSession({email:creds[n][0],password:creds[n][1]});
   const me=await acc.get();
   users[n]={client:c,id:me.$id};
  }catch(e){bad('user '+n+' session: '+e.code+' '+e.message);return}
 }
 ok('two test users created and signed in');
 // A saves m1, B saves m2
 for(const [n,mid] of [['a','m1'],['b','m2']]){
  useJar(n);
  const t=new TablesDB(users[n].client);
  try{
   const row=await t.createRow({databaseId:DB,tableId:'saved_matches',rowId:ID.unique(),data:{matchId:mid},permissions:[Permission.read(Role.user(users[n].id)),Permission.delete(Role.user(users[n].id))]});
   users[n].row=row.$id;ok(n+' saved '+mid+' ('+row.$id+')');
  }catch(e){bad(n+' create saved: '+e.code+' '+e.message)}
 }
 // each lists only own
 for(const n of ['a','b']){
  useJar(n);
  const t=new TablesDB(users[n].client);
  try{const r=await t.listRows({databaseId:DB,tableId:'saved_matches'});
   const ids=r.rows.map(x=>x.$id);
   ids.length===1&&ids[0]===users[n].row?ok(n+' lists exactly own save'):bad(n+' sees '+JSON.stringify(ids));
  }catch(e){bad(n+' list saved: '+e.code)}
 }
 // B tries to read A's row
 useJar('b');
 const tb=new TablesDB(users.b.client);
 try{await tb.getRow({databaseId:DB,tableId:'saved_matches',rowId:users.a.row});bad('B READ A row')}catch(e){(e.code===404||e.code===401)?ok('B cannot read A row ('+e.code+')'):bad('B read A: '+e.code)}
 try{await tb.deleteRow({databaseId:DB,tableId:'saved_matches',rowId:users.a.row});bad('B DELETED A row')}catch(e){(e.code===404||e.code===401)?ok('B cannot delete A row ('+e.code+')'):bad('B del A: '+e.code)}
 // A deletes own row (unsave path)
 useJar('a');
 const ta=new TablesDB(users.a.client);
 try{await ta.deleteRow({databaseId:DB,tableId:'saved_matches',rowId:users.a.row});ok('A deleted own save')}catch(e){bad('A delete own: '+e.code)}
 // match payload integrity: pull one and parse
 useJar('anon');
 try{const r=await at.listRows({databaseId:DB,tableId:'matches',queries:[Query.equal('dataMode','demo')],limit:1});const p=JSON.parse(r.rows[0].payload);p.id?ok('payload parses, id='+p.id):bad('payload missing id')}catch(e){bad('payload parse: '+e.message)}
 console.log(fail.length?`RESULT: ${fail.length} FAILURES`:'RESULT: ALL PASS');
})().catch(e=>{console.error('FATAL',e);process.exit(1)});
