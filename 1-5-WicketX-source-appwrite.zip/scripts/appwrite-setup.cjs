const sdk=require('node-appwrite');
const fs=require('fs');
const esbuild=require('esbuild');
const key=fs.readFileSync('/home/sandbox/.wicketx-setup-key','utf8').trim();
const client=new sdk.Client().setEndpoint('https://fra.cloud.appwrite.io/v1').setProject('6ada539900103d47b12c').setKey(key);
const db=new sdk.Databases(client);const tables=new sdk.TablesDB(client);
const DB='wicketx';
(async()=>{
 try{await db.create({databaseId:DB,name:'WicketX'});console.log('database created')}catch(e){if(e.code===409)console.log('database exists');else throw e}
 try{await tables.createTable({databaseId:DB,tableId:'matches',name:'Matches',permissions:[sdk.Permission.read(sdk.Role.any())],rowSecurity:false});console.log('matches table created')}catch(e){if(e.code===409)console.log('matches table exists');else throw e}
 try{await tables.createStringColumn({databaseId:DB,tableId:'matches',key:'payload',size:8192,required:true});console.log('payload column')}catch(e){if(e.code===409)console.log('payload exists');else throw e}
 try{await tables.createStringColumn({databaseId:DB,tableId:'matches',key:'dataMode',size:16,required:true});console.log('dataMode column')}catch(e){if(e.code===409)console.log('dataMode exists');else throw e}
 try{await tables.createTable({databaseId:DB,tableId:'saved_matches',name:'Saved matches',permissions:[sdk.Permission.create(sdk.Role.users())],rowSecurity:true});console.log('saved_matches table created')}catch(e){if(e.code===409)console.log('saved_matches table exists');else throw e}
 try{await tables.createStringColumn({databaseId:DB,tableId:'saved_matches',key:'matchId',size:64,required:true});console.log('matchId column')}catch(e){if(e.code===409)console.log('matchId exists');else throw e}
 // compile data.ts to plain JS and import it
 const ts=fs.readFileSync('/home/sandbox/boundary/src/data.ts','utf8');
 const js=esbuild.transformSync(ts,{loader:'ts',format:'esm'}).code;
 fs.writeFileSync('/tmp/data-module.mjs',js);
 const mod=await import('/tmp/data-module.mjs');
 const rows=mod.matches||mod.MATCHES||mod.default;
 if(!Array.isArray(rows)||!rows.length)throw new Error('matches export not found: '+Object.keys(mod).join(','));
 for(const m of rows){
  try{await tables.createRow({databaseId:DB,tableId:'matches',rowId:m.id,data:{payload:JSON.stringify(m),dataMode:'demo'}});console.log('seeded',m.id)}catch(e){if(e.code===409)console.log('exists',m.id);else throw e}
 }
 console.log('setup complete');
})().catch(e=>{console.error('FAILED',e.code,e.message);process.exit(1)});
