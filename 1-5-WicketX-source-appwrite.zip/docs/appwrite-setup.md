# Appwrite project setup, pending account access

Free plan only. Do not delete existing resources or choose paid compute to obtain project capacity.

## Public configuration

Set VITE_APPWRITE_ENDPOINT, PROJECT_ID and DATABASE_ID only after creating/reading the actual project. Default table ids: matches, saved_matches. None is an administrative secret. Do not place API keys in VITE variables.

## Database schema and permissions

One database with two tables:

- matches: payload string (JSON representation of original Match shape, max 8192), dataMode string (demo). Row ids m1-m6. Public table read only. No client create/update/delete. Seed each match preserving the existing illustrative values with dataMode demo.
- saved_matches: matchId string (max 36). Row Security ON. Table permits create to authenticated users only; no table read/update/delete. Each row grants read/delete only to its creating account. No ownerId field is trusted or necessary; permission, not data, establishes ownership. Client cannot grant an unrelated user's permission it does not possess, per Appwrite's documented permission model. Verify this with a second account before delivery.

Default matching permissions are in src/backend.ts. Auth uses Appwrite account SDK, not application-stored passwords. No realtime subscriptions or file bucket are required.

## Platforms and callback

Add the real website hostname and local development host as Web platforms. Verification/recovery callbacks are current origin/path with auth query and Account hash route. Do not use a guessed production hostname. Android app uses bundled Capacitor web assets with https local origin; configure and verify supported Android/web session behavior on device before claiming native auth works.

## API coverage

Appwrite Account API: create account, email/password session, get account, delete current session, verification, password recovery.
TablesDB API: public match reads; permission-scoped saved row list/create/delete. getSaves paginates through accessible rows. No server admin credential is needed in the client.

## Required validation

Cloud account signup/login/session/logout; real verification/recovery delivery; anonymous public reads; denied anonymous/private writes; denied cross-account row access, overwrite/deletion and unauthorized permission grants; refresh persistence; offline/errors; actual Android session test. Local build success and browser tests without project config do not satisfy these checks.
