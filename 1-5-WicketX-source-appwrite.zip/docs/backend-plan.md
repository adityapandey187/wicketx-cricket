# Backend addition plan

Status: preparation only. Service identity and account setup remain unconfirmed. No backend integration is implemented or deployed by this document. Existing v2 demo remains unchanged.

## Scope

- Database for match data and signed-in users' saved matches.
- Email/password signup, login, sign out, session restore, verification and recovery.
- Backend API for match reads and private saved-match operations.
- No file uploads or real-time subscriptions.
- Public scores remain explicitly illustrative until a licensed provider is connected.

## Data model

`matches`: public read, no public write. Stable id, two teams/codes/scores/overs, format, series, venue, illustrative schedule, status, note, `dataMode: demo`, updatedAt. Sample data is seeded by project owner, never an unauthenticated client.

`saved_matches`: deterministic record id from account id plus match id, owner id, match id, createdAt. Authenticated users create only their own records. Read/update/delete restricted to the owning account. Never list all records then filter in the browser. Unique owner/match pair prevents duplicates.

Account profile data should stay in the chosen service's authentication account where possible. Do not duplicate passwords, recovery secrets or session tokens in application tables. Do not store persistent auth secrets in localStorage manually.

## Client behavior

- Without provider config, keep existing demo browsing and local-only saved matches. Do not show a working cloud-login claim.
- With provider config, render public records through the backend; show loading, empty and error states separately. Never silently relabel bundled sample data as current server data.
- Allow login/signup without blocking public browsing. Clear password inputs after use and do not log them.
- Signing in must not silently upload the device's existing saved matches. Offer explicit import or leave local saves separate.
- Logout clears private state in memory. Account switching must never flash another account's saved matches.
- Verification/recovery redirects must target registered website/mobile routes. Remove temporary recovery/verification values from URL after processing.
- Android packaged-app session behavior needs its own actual-device test; a web session test is not proof of Android behavior.

## Security and configuration

Only project id, public endpoint and non-secret resource ids belong in web config. Administrative API keys and cricket-provider keys are server-only. Use restrictive record permissions, correct platform/domain allowlists and supported session handling. Confirm the selected plan is Free and stop on any paid prompt or exhausted free project limit. Do not delete existing resources to free capacity.

## Acceptance checks before hosted review

1. Build and existing five interaction/layout tests still pass.
2. Create a test account, sign in, refresh to restore session, sign out; invalid credentials fail safely.
3. Verify/recover account using real provider flows; expired/invalid links show a safe error. No secrets in logs or delivered archive.
4. Save/unsave a match, reload and check persistence. Duplicate saves remain one record.
5. Second account cannot read, modify or delete first account's saves, including direct API requests. Anonymous requests cannot write match records or private saves.
6. Wrong owner id on create is rejected by provider permissions or trusted backend validation.
7. Offline/error state is clear; bundled demo remains labelled, never passed off as fresh data.
8. Inspect mobile/desktop pixels after account UI changes. Rebuild APK and keep runtime-unverified label until actual-device testing passes.
9. Verify hosted URL, routes, TLS, account permissions, Free plan and public/private audience before claiming delivery.

## Open checks

Exact service and account identity; free project capacity; region and provider APIs; email/recovery delivery; Android session storage/cookies; licensed live score provider. None is settled by this plan.
