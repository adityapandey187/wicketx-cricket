package in.adityapandey.wicketx;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
