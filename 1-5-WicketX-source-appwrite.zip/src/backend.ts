import {Client,Account,TablesDB,ID,Permission,Role,Query} from 'appwrite';
import type {Match} from './data';
const env=(import.meta as any).env;
export const configured=Boolean(env.VITE_APPWRITE_ENDPOINT&&env.VITE_APPWRITE_PROJECT_ID&&env.VITE_APPWRITE_DATABASE_ID);
const client=new Client();
if(configured)client.setEndpoint(env.VITE_APPWRITE_ENDPOINT).setProject(env.VITE_APPWRITE_PROJECT_ID);
export const account=new Account(client);
const db=new TablesDB(client);
const databaseId=env.VITE_APPWRITE_DATABASE_ID||'';
const matchesId=env.VITE_APPWRITE_MATCHES_TABLE||'matches';
const savesId=env.VITE_APPWRITE_SAVES_TABLE||'saved_matches';
export async function getMatches():Promise<Match[]>{
 const result=await db.listRows({databaseId,tableId:matchesId,queries:[Query.limit(100)]});
 return result.rows.map(row=>{if(row.dataMode!=='demo')throw new Error('Unsupported match data mode');const match=JSON.parse(row.payload);if(!match.id||!Array.isArray(match.teams)||match.teams.length!==2)throw new Error('Invalid match record');return match as Match});
}
export async function getSaves(){const rows:{id:string;matchId:string}[]=[];let cursor='';for(;;){const result=await db.listRows({databaseId,tableId:savesId,queries:[Query.limit(100),...(cursor?[Query.cursorAfter(cursor)]:[])]});rows.push(...result.rows.map(row=>({id:row.$id,matchId:String(row.matchId)})));if(result.rows.length<100)break;cursor=result.rows[result.rows.length-1].$id;}return rows;}
export async function saveMatch(matchId:string,userId:string){return db.createRow({databaseId,tableId:savesId,rowId:ID.unique(),data:{matchId},permissions:[Permission.read(Role.user(userId)),Permission.delete(Role.user(userId))]});}
export async function removeSave(id:string){return db.deleteRow({databaseId,tableId:savesId,rowId:id});}
export async function signIn(email:string,password:string){await account.createEmailPasswordSession({email,password});return account.get();}
export async function signUp(name:string,email:string,password:string){await account.create({userId:ID.unique(),email,password,name});return signIn(email,password);}
export const callbackUrl=(mode:string)=>location.origin+location.pathname+'?auth='+mode+'#Account';
