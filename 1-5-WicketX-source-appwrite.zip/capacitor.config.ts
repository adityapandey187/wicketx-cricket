import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'in.adityapandey.wicketx', appName: 'WicketX', webDir: 'dist', android: {backgroundColor: '#FFF8E8'}, server: {androidScheme: 'https'} };
export default config;
