import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'in.adityapandey.boundary', appName: 'Boundary', webDir: 'dist', android: {backgroundColor: '#f5f5f8'}, server: {androidScheme: 'https'} };
export default config;
