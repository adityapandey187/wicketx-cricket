package in.adityapandey.boundary;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
